public interface Transportemercancias {

    default String introducirDireccionDestino(){
        return "DireccionDestino";
    }
}
