public  interface PrezuUso {

     default void prezoUso( int horas, int combustible, int enerxia, int combustion, double cantidadamas){

    }

}
