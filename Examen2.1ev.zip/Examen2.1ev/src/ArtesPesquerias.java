public interface ArtesPesquerias {

    default void arrastres(){

    }

    default void cerco(){

    }

}
