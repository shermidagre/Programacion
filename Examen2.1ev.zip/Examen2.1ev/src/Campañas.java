public interface Campañas {

      default void resultadoCampaña(int calidade, int valor, int tonelada){

          System.out.println(" A calidade e " + calidade + " o valor e " + valor + " levant " + tonelada + " tonelada/s ");

    }

}
