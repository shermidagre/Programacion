public interface CamaraFrigorifica {


    default boolean tienencamarafrigorifica (boolean camara) {

        boolean camarafrigorifica;

        if (camarafrigorifica = true) {
            System.out.println("Tienen" + camara);

        }
        else return false;

        return camarafrigorifica;
    }

}
